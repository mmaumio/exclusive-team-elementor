=== Exclusive Team for Elementor ===
Contributors: devscred, mmaumio
Donate link: https://www.paypal.me/Aumio
Tags: team, team-carousel, exclusive-team, elementor, elementor-addons
Requires at least: 3.8
Tested up to: 5.0.2
Stable tag: 5.0.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Team Member and Team Carousel Element for Elementor

== Description ==

Exclusive Team for Elementor Plugin consist a beuatifully designed and crafted Team Member and Team Member Carousel widget for Elementor


== Installation ==

1. Download "Exclusive Team for Elementor" plugin
2. Simply go to the Plugins page, then click on Add new and select the plugin's .zip file which is “ExclusiveTeam.zip".
3. Alternatively you can extract the contents of the zip file directly to your wp-content/plugins/ folder
4. Finally, activate the plugin.

== Frequently Asked Questions ==

= Does it require to Elementor being Installed ? =

Yes.

= Is there any shortcode to use it in a page or post ? =

Not at the moment.


== Screenshots ==


== Changelog ==


= 1.0 =
Initial release


Looking for upgrades? Please keep patience.
